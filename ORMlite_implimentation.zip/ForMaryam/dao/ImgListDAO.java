/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.presa.imageclassifierdb.dao;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.SelectArg;
import com.presa.imageclassifierdb.JdbcUtil;
import com.presa.imageclassifierdb.model.ImgClasses;
import com.presa.imageclassifierdb.model.ImgSubclasses;
import com.presa.imageclassifierdb.model.TestImgListAttrs;
import com.presa.imageclassifierdb.model.TestImgListClassRel;
import com.presa.imageclassifierdb.model.TestImglistUrl;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Maria
 */
public class ImgListDAO {
    
    
    /* 
    //get attributes by image name
    "SELECT ts.attr_CH as a4 ,ts.attr_CM55 as b,attr_CORR as c,attr_EDH as d,
    attr_WT as e  FROM imageretrival.test_imglist_attributes as ts JOIN 
    imageretrival.test_imglist_urls as u on u.id=ts.fk_img_id where u.img_name =" + Filename ;    
    */
    
    /*

    sql1 = "SELECT t1.url_small as url FROM imageretrival.train_imglist_urls 
    AS t1 JOIN imageretrival.train_imglist_class_rel AS t2 WHERE t1.id = t2.fk_img_id 
    AND t2.fk_class_id=" + classid + " ORDER BY RAND() limit 1";
    
      sql2 = "SELECT class_name FROM imageretrival.img_classes where class_id=" + classid;
    */
    
    private static JdbcUtil ju;

    public ImgListDAO() {
        ju = new JdbcUtil();
    }
    
    public void closeDBConnection(){
        ju.disConnect();
    }
    
    
    
    public static List<ImgClasses> getAllImgClasses() {

        List<ImgClasses> imgclasses = null;
        Dao imgClassDao = ju.getDao(ImgClasses.class);

        try {
            imgclasses = imgClassDao.queryForAll();

        } catch (SQLException ex) {
            Logger.getLogger(ImgListDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return imgclasses;
    }
    
    public static List<TestImglistUrl> getAllTestImgs(){
        
        List<TestImglistUrl> testImg = null;
        Dao testImgListDao = ju.getDao(TestImglistUrl.class);
        Dao testImgListClassRelDao = ju.getDao(TestImgListClassRel.class);
        
        QueryBuilder<TestImglistUrl, Integer> ImgListQB = testImgListDao.queryBuilder();
        
        QueryBuilder<TestImgListClassRel,Integer> ImgClassRelQB2 = testImgListClassRelDao.queryBuilder();
      
        try {
            ImgClassRelQB2.selectColumns(TestImgListClassRel.TEST_IMG_ID);
            ImgClassRelQB2.groupBy(TestImgListClassRel.TEST_IMG_ID).having("Count("+TestImgListClassRel.TEST_IMG_ID+") = 1");
            ImgClassRelQB2.orderByRaw("RAND()");
            
            ImgListQB.where().in(TestImglistUrl.COLUMN_ID, ImgClassRelQB2);
            
            ImgListQB.limit((long) 100);
            ImgListQB.where().ne(TestImglistUrl.COLUMN_URL_SMALL, "NULL");
            
            testImg = ImgListQB.query();


        } catch (SQLException ex) {
            Logger.getLogger(ImgListDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return testImg;
    }

    /*
    sql1 = "SELECT t1.url_small as url FROM imageretrival.train_imglist_urls 
    AS t1 JOIN imageretrival.train_imglist_class_rel AS t2 WHERE t1.id = t2.fk_img_id 
    AND t2.fk_class_id=" + classid + " ORDER BY RAND() limit 1";
    */
    public static List<TestImglistUrl> getClassTestImgs(int class_id) {

        List<TestImglistUrl> testImg = null;
        Dao testImgListDao = ju.getDao(TestImglistUrl.class);
        Dao testImgListClassRelDao = ju.getDao(TestImgListClassRel.class);
        Dao imgSubClassDao = ju.getDao(ImgSubclasses.class);
        Dao imgClassDao = ju.getDao(ImgClasses.class);
        
        QueryBuilder<TestImglistUrl, Integer> ImgListQB = testImgListDao.queryBuilder();
        QueryBuilder<TestImgListClassRel,Integer> ImgClassRelQB = testImgListClassRelDao.queryBuilder();
        QueryBuilder<ImgClasses, Integer> ImgClassQB = imgClassDao.queryBuilder();
        
        QueryBuilder<TestImgListClassRel,Integer> ImgClassRelQB2 = testImgListClassRelDao.queryBuilder();
      
        try {
            ImgClassQB.where().eq(ImgClasses.COLUMN_ID, class_id);
            
            ImgClassRelQB.join(ImgClassQB);
            ImgClassRelQB2.selectColumns(TestImgListClassRel.TEST_IMG_ID);
            ImgClassRelQB2.groupBy(TestImgListClassRel.TEST_IMG_ID).having("Count("+TestImgListClassRel.TEST_IMG_ID+") = 1");
            ImgClassRelQB2.orderByRaw("RAND()");
            
            ImgListQB.where().in(TestImglistUrl.COLUMN_ID, ImgClassRelQB2);
            ImgListQB.join(ImgClassRelQB);
            ImgListQB.limit((long) 1);
            
            testImg = ImgListQB.query();

            //refresh and get the subclass of each 
            //image
            for(TestImglistUrl test: testImg)
                imgSubClassDao.refresh(test.getSubclass());

        } catch (SQLException ex) {
            Logger.getLogger(ImgListDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return testImg;
    }
    
    
    
    
    /*"SELECT ts.attr_CH as a4 ,ts.attr_CM55 as b,attr_CORR as c,attr_EDH as d,
    attr_WT as e  
    FROM 
    imageretrival.test_imglist_attributes as ts JOIN 
    imageretrival.test_imglist_urls as u on u.id=ts.fk_img_id where u.img_name =" + Filename ;   
    */
    public static String getImageTestAttributes(String filename){
        
        String result="";
        Dao testImgListDao = ju.getDao(TestImglistUrl.class);
        Dao testImgAttrsDao = ju.getDao(TestImgListAttrs.class);
        
        QueryBuilder<TestImglistUrl, Integer> ImgListQB = testImgListDao.queryBuilder();
        QueryBuilder<TestImgListAttrs, Integer> ImgAttrQB = testImgAttrsDao.queryBuilder();
        
        try {
            ImgListQB.where().eq(TestImglistUrl.COLUMN_IMG_NAME, filename);
            ImgAttrQB.join(ImgListQB);
            
            TestImgListAttrs attr = ImgAttrQB.queryForFirst();
            
            result = attr.getAttr_ch()+attr.getAttr_cm55()+attr.getAttr_corr()+attr.getAttr_edh()+attr.getAttr_wt();
        }
        catch (SQLException ex) {
            Logger.getLogger(ImgListDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        return result;
    }
    
    //sql2 = "SELECT class_name FROM imageretrival.img_classes where class_id=" + classid;
    public static String getImgClass(int classid){
        
        String result = "";
        
        Dao imgClassDao = ju.getDao(ImgClasses.class);
        
        try{
            
            ImgClasses imgclass = (ImgClasses) imgClassDao.queryForId(classid);
            result = imgclass.getClass_name();
            
        }catch (SQLException ex) {
            Logger.getLogger(ImgListDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return result;
    }
}
