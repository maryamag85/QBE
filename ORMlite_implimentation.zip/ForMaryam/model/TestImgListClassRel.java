/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.presa.imageclassifierdb.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 *
 * @author Maria
 */

@DatabaseTable(tableName = "TEST_IMGLIST_CLASS_REL")
public class TestImgListClassRel {
    
    public final static String TEST_IMG_ID = "FK_IMG_ID";
    public final static String CLASS_ID = "FK_CLASS_ID";
    
    @DatabaseField(foreign=true, index=true, columnName=CLASS_ID ) 
    private ImgClasses img_class_id;
    
    @DatabaseField(foreign=true, index=true, columnName=TEST_IMG_ID) 
    private TestImglistUrl test_img_list_id;
    
    
    TestImgListClassRel(){}

    public ImgClasses getImg_class_id() {
        return img_class_id;
    }

    public void setImg_class_id(ImgClasses img_class_id) {
        this.img_class_id = img_class_id;
    }

    public TestImglistUrl getTest_img_list_id() {
        return test_img_list_id;
    }

    public void setTest_img_list_id(TestImglistUrl test_img_list_id) {
        this.test_img_list_id = test_img_list_id;
    }
    
}
