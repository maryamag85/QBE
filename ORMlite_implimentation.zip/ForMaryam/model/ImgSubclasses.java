/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.presa.imageclassifierdb.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 *
 * @author Maria
 */
@DatabaseTable(tableName = "IMG_SUBCLASSES")
public class ImgSubclasses {
    
    public static final String COLUMN_ID = "id";
    
    @DatabaseField(id = true)
    private int id;
    
    @DatabaseField
    private String class_name;
    
    ImgSubclasses(){
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }
    
}
