/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.presa.imageclassifierdb.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 *
 * @author Maria
 */
@DatabaseTable(tableName = "TRAIN_IMGLIST_URL")
public class TrainImglistUrl {
    
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_IMG_NAME = "IMG_NAME"; 
    public static final String COLUMN_SUBCLASS_ID = "SUBCLASS_ID"; 
    
    public static final String COLUMN_URL_ORIG = "URL_ORIG"; 
    public static final String COLUMN_URL_SMALL = "URL_SMALL"; 
    
    @DatabaseField(id = true)
    private int id;
    
    @DatabaseField
    private String img_name;
    
    @DatabaseField(foreign=true, columnName=COLUMN_SUBCLASS_ID)
    private ImgSubclasses subclass;
    
    @DatabaseField
    private String url_large;
    
    @DatabaseField
    private String url_middle;
    
    @DatabaseField
    private String url_small;
    
    @DatabaseField
    private String url_orig;
    
    TrainImglistUrl(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImg_name() {
        return img_name;
    }

    public void setImg_name(String img_name) {
        this.img_name = img_name;
    }

    public ImgSubclasses getSubclass() {
        return subclass;
    }

    public void setSubclass(ImgSubclasses subclass) {
        this.subclass = subclass;
    }

    public String getUrl_large() {
        return url_large;
    }

    public void setUrl_large(String url_large) {
        this.url_large = url_large;
    }

    public String getUrl_middle() {
        return url_middle;
    }

    public void setUrl_middle(String url_middle) {
        this.url_middle = url_middle;
    }

    public String getUrl_small() {
        return url_small;
    }

    public void setUrl_small(String url_small) {
        this.url_small = url_small;
    }

    public String getUrl_orig() {
        return url_orig;
    }

    public void setUrl_orig(String url_orig) {
        this.url_orig = url_orig;
    }
    
    
}
