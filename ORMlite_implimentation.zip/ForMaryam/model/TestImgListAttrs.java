package com.presa.imageclassifierdb.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maria
 */
@DatabaseTable(tableName = "TEST_IMGLIST_ATTRS")
public class TestImgListAttrs {
    public static final String COLUMN_ID = "FK_IMG_ID";
    public static final String COLUMN_ATTR_CH = "ATTR_CH"; 
    public static final String COLUMN_ATTR_CM55 = "ATTR_CM55"; 
    public static final String COLUMN_ATTR_CORR = "ATTR_CORR"; 
    public static final String COLUMN_ATTR_EDH = "ATTR_EDH"; 
    public static final String COLUMN_ATTR_WT = "ATTR_WT"; 
    
    @DatabaseField(id = true, foreign = true, columnName = COLUMN_ID)
    private int id;
    
    @DatabaseField(columnName = COLUMN_ATTR_CH)
    private String attr_ch;
    
    @DatabaseField(columnName = COLUMN_ATTR_CM55)
    private String attr_cm55;
    
    @DatabaseField(columnName = COLUMN_ATTR_CORR)
    private String attr_corr;
    
    @DatabaseField(columnName = COLUMN_ATTR_EDH)
    private String attr_edh;
     
    @DatabaseField(columnName = COLUMN_ATTR_WT)
    private String attr_wt;
      
    TestImgListAttrs(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAttr_ch() {
        return attr_ch;
    }

    public void setAttr_ch(String attr_ch) {
        this.attr_ch = attr_ch;
    }

    public String getAttr_cm55() {
        return attr_cm55;
    }

    public void setAttr_cm55(String attr_cm55) {
        this.attr_cm55 = attr_cm55;
    }

    public String getAttr_corr() {
        return attr_corr;
    }

    public void setAttr_corr(String attr_corr) {
        this.attr_corr = attr_corr;
    }

    public String getAttr_edh() {
        return attr_edh;
    }

    public void setAttr_edh(String attr_edh) {
        this.attr_edh = attr_edh;
    }

    public String getAttr_wt() {
        return attr_wt;
    }

    public void setAttr_wt(String attr_wt) {
        this.attr_wt = attr_wt;
    }
    
    
}
