/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.presa.imageclassifierdb;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Maria
 */
public class JdbcUtil {
    private static ConnectionSource connectionSource;
    private static final String DATABASE_URL = "jdbc:h2:" + Paths.get("").toAbsolutePath() 
                                                + "\\lib\\imgdb;FILE_LOCK=SOCKET;IFEXISTS=TRUE";
    private Dao dao;
    
    public JdbcUtil(){
        try {
            connectionSource = new JdbcConnectionSource(DATABASE_URL, "root", "");
        } catch (SQLException ex) {
            Logger.getLogger(JdbcUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public Dao getDao(Class classForDao){
        try {
            dao= DaoManager.createDao(connectionSource, classForDao);
            return dao;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                    "Make sure the database file imgdb.mv\n is in the lib directory folder\n"+e.getMessage(), 
                    "Something went wrong", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
        return null;
    }
    

    public void disConnect(){
        try {
            connectionSource.close();
            System.out.println("Closed Succesfully!");
        } catch (SQLException e) {
        }
    }
}
